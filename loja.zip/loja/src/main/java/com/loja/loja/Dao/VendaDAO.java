package com.loja.loja.Dao;

import com.loja.loja.Model.Produto;
import com.loja.loja.Model.Venda;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class VendaDAO {

    private Connection connection;

    public VendaDAO() throws SQLException {
        this.connection = DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/loja", "root", "daniS1974@");
    }

    public List<Venda> listarVendas() throws SQLException {
        List<Venda> vendas = new ArrayList<>();
        String sql = "SELECT * FROM Venda";
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {
            while (resultSet.next()) {
                Venda venda = new Venda(
                    resultSet.getInt("id"),
                    resultSet.getString("produto"),
                    resultSet.getInt("quantidade"),
                    resultSet.getDouble("valorTotal"),
                    resultSet.getDate("dataVenda").toLocalDate()
                );
                vendas.add(venda);
            }
        }
        return vendas;
    }

    public void cadastrarVenda(Venda venda) throws SQLException {
        ProdutoDAO produtoDAO = new ProdutoDAO();
        Produto produto = produtoDAO.buscarProdutoPorNome(venda.getProduto());

        if (produto == null) {
            throw new SQLException("Produto não encontrado: " + venda.getProduto());
        }

        if (produto.getQuantidade() < venda.getQuantidade()) {
            throw new SQLException("Quantidade solicitada excede o estoque disponível.");
        }

        // Atualizar a quantidade do produto
        int novaQuantidade = produto.getQuantidade() - venda.getQuantidade();
        produto.setQuantidade(novaQuantidade);
        produtoDAO.atualizarProduto(produto);

        // Cadastrar a venda
        String sql = "INSERT INTO Venda (produto, quantidade, valorTotal, dataVenda) VALUES (?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, venda.getProduto());
            statement.setInt(2, venda.getQuantidade());
            statement.setDouble(3, venda.getValorTotal());
            statement.setDate(4, Date.valueOf(venda.getDataVenda()));
            statement.executeUpdate();
        }
    }
}
