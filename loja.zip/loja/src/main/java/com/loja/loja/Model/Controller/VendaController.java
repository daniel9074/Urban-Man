package com.loja.loja.Model.Controller;

import com.loja.loja.Model.Produto;
import com.loja.loja.Model.Venda;
import com.loja.loja.Dao.ProdutoDAO;
import com.loja.loja.Dao.VendaDAO;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.ui.Model;

import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

@Controller
public class VendaController {

    private VendaDAO vendaDAO;
    private ProdutoDAO produtoDAO;

    public VendaController() throws SQLException {
        this.vendaDAO = new VendaDAO();
        this.produtoDAO = new ProdutoDAO();
    }

    @GetMapping("/venda")
    public String exibirVendaPage(Model model) throws SQLException {
        List<Venda> vendas = vendaDAO.listarVendas();
        model.addAttribute("vendas", vendas);
        return "venda";
    }

    @PostMapping("/venda")
    public String cadastrarVenda(
            @RequestParam("produto") String produtoNome,
            @RequestParam("quantidade") int quantidade,
            @RequestParam("valorTotal") double valorTotal,
            @RequestParam("dataVenda") String dataVendaStr,
            Model model) {

        LocalDate dataVenda = LocalDate.parse(dataVendaStr);

        try {
            Produto produto = produtoDAO.buscarProdutoPorNome(produtoNome);

            if (produto == null) {
                model.addAttribute("mensagem", "Produto não encontrado: " + produtoNome);
                return "venda";
            }

            if (produto.getQuantidade() < quantidade) {
                model.addAttribute("mensagem", "Quantidade solicitada excede o estoque disponível.");
                return "venda";
            }

            
            produtoDAO.atualizarProduto(produto);

            Venda venda = new Venda(0, produtoNome, quantidade, valorTotal, dataVenda);
            vendaDAO.cadastrarVenda(venda);

            model.addAttribute("mensagem", "Venda cadastrada com sucesso!");

            List<Venda> vendas = vendaDAO.listarVendas();
            model.addAttribute("vendas", vendas);

        } catch (SQLException e) {
            model.addAttribute("mensagem", "Erro ao cadastrar venda: " + e.getMessage());
        }

        return "venda";
    }
}
