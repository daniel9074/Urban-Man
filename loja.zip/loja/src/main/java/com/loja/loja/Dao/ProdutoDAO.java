package com.loja.loja.Dao;

import com.loja.loja.Model.Produto;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProdutoDAO {

    private Connection connection;

    public ProdutoDAO() throws SQLException {
        this.connection = DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/loja", "root", "daniS1974@");
    }

    public void cadastrarProduto(Produto produto) throws SQLException {
        String sql = "INSERT INTO Produto (nome, marca, valor, descricao, quantidade) VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, produto.getNome());
            statement.setString(2, produto.getMarca());
            statement.setDouble(3, produto.getValor());
            statement.setString(4, produto.getDescricao());
            statement.setInt(5, produto.getQuantidade());  // Adiciona a quantidade
            statement.executeUpdate();
        }
    }

    public List<Produto> listarProdutos() throws SQLException {
        List<Produto> produtos = new ArrayList<>();
        String sql = "SELECT * FROM Produto";
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {
            while (resultSet.next()) {
                Produto produto = new Produto(
                    resultSet.getInt("id"),
                    resultSet.getString("nome"),
                    resultSet.getString("marca"),
                    resultSet.getDouble("valor"),
                    resultSet.getString("descricao"),
                    resultSet.getInt("quantidade")  // Obtém a quantidade
                );
                produtos.add(produto);
            }
        }
        return produtos;
    }
    
    // Adicione isso à classe ProdutoDAO
public Produto buscarProdutoPorNome(String nome) throws SQLException {
    String sql = "SELECT * FROM Produto WHERE nome = ?";
    try (PreparedStatement statement = connection.prepareStatement(sql)) {
        statement.setString(1, nome);
        try (ResultSet resultSet = statement.executeQuery()) {
            if (resultSet.next()) {
                return new Produto(
                    resultSet.getInt("id"),
                    resultSet.getString("nome"),
                    resultSet.getString("marca"),
                    resultSet.getDouble("valor"),
                    resultSet.getString("descricao"),
                    resultSet.getInt("quantidade")
                );
            }
        }
    }
    return null;
}
public void atualizarProduto(Produto produto) throws SQLException {
    String sql = "UPDATE Produto SET quantidade = ? WHERE nome = ?";
    try (PreparedStatement statement = connection.prepareStatement(sql)) {
        statement.setInt(1, produto.getQuantidade());
        statement.setString(2, produto.getNome());
        statement.executeUpdate();
    }
}


}
