package com.loja.loja.Model.Controller;

import com.loja.loja.Model.Produto;
import com.loja.loja.Dao.ProdutoDAO;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.ui.Model;

import java.sql.SQLException;
import java.util.List;

@Controller
public class ProdutoController {

    private ProdutoDAO produtoDAO;

    public ProdutoController() throws SQLException {
        this.produtoDAO = new ProdutoDAO();
    }

    @GetMapping("/produto")
    public String exibirProdutoPage(Model model) throws SQLException {
        List<Produto> produtos = produtoDAO.listarProdutos();
        model.addAttribute("produtos", produtos);
        return "produto";
    }

    @PostMapping("/produto")
    public String cadastrarProduto(
            @RequestParam("nome") String nome,
            @RequestParam("marca") String marca,
            @RequestParam("valor") double valor,
            @RequestParam("descricao") String descricao,
            @RequestParam("quantidade") int quantidade,  // Adicionado o parâmetro quantidade
            Model model) {

        Produto produto = new Produto(0, nome, marca, valor, descricao, quantidade);  // Adicionado o valor da quantidade
        try {
            produtoDAO.cadastrarProduto(produto);
            model.addAttribute("mensagem", "Produto cadastrado com sucesso!");
        } catch (SQLException e) {
            model.addAttribute("mensagem", "Erro ao cadastrar produto: " + e.getMessage());
        }

        try {
            List<Produto> produtos = produtoDAO.listarProdutos();
            model.addAttribute("produtos", produtos);
        } catch (SQLException e) {
            model.addAttribute("mensagem", "Erro ao listar produtos: " + e.getMessage());
        }

        return "produto";
    }
}
