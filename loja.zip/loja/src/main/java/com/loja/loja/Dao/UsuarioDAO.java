package com.loja.loja.Dao;

import com.loja.loja.Model.Usuario;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDAO {

    private Connection connection;

    public UsuarioDAO() throws SQLException {
        this.connection = DriverManager.getConnection(
            "jdbc:mysql://localhost:3306/loja", "root", "daniS1974@");
    }

    // Método para cadastrar um novo usuário
    public void cadastrarUsuario(Usuario usuario) throws SQLException {
        String sql = "INSERT INTO Usuario (nome, email, telefone, endereco) VALUES (?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, usuario.getNome());
            statement.setString(2, usuario.getEmail());
            statement.setString(3, usuario.getTelefone());
            statement.setString(4, usuario.getEndereco());
            statement.executeUpdate();
        }
    }

    // Método para listar todos os usuários
    public List<Usuario> listarUsuarios() throws SQLException {
        List<Usuario> usuarios = new ArrayList<>();
        String sql = "SELECT * FROM Usuario";
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {
            while (resultSet.next()) {
                Usuario usuario = new Usuario(
                    resultSet.getInt("id"),
                    resultSet.getString("nome"),
                    resultSet.getString("email"),
                    resultSet.getString("telefone"),
                    resultSet.getString("endereco")
                );
                usuarios.add(usuario);
            }
        }
        return usuarios;
    }
}
