package com.loja.loja.Model.Controller;

import com.loja.loja.Model.Usuario;
import com.loja.loja.Dao.UsuarioDAO;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.ui.Model;

import java.sql.SQLException;
import java.util.List;

@Controller
public class UsuarioController {

    private UsuarioDAO usuarioDAO;

    public UsuarioController() throws SQLException {
        this.usuarioDAO = new UsuarioDAO();
    }

    // Exibir a página de cadastro de usuário e listar os usuários cadastrados
    @GetMapping("/usuario")
    public String exibirUsuarioPage(Model model) throws SQLException {
        List<Usuario> usuarios = usuarioDAO.listarUsuarios();
        model.addAttribute("usuarios", usuarios);
        return "usuario";
    }

    // Cadastrar um novo usuário
    @PostMapping("/usuario")
    public String cadastrarUsuario(
            @RequestParam("nome") String nome,
            @RequestParam("email") String email,
            @RequestParam("telefone") String telefone,
            @RequestParam("endereco") String endereco,
            Model model) {

        // Criando um objeto Usuario com os dados recebidos
        Usuario usuario = new Usuario(0, nome, email, telefone, endereco);
        try {
            // Cadastrar usuário no banco de dados
            usuarioDAO.cadastrarUsuario(usuario);
            model.addAttribute("mensagem", "Usuário cadastrado com sucesso!");
        } catch (SQLException e) {
            model.addAttribute("mensagem", "Erro ao cadastrar usuário: " + e.getMessage());
        }

        // Listar todos os usuários para exibição na tabela
        try {
            List<Usuario> usuarios = usuarioDAO.listarUsuarios();
            model.addAttribute("usuarios", usuarios);
        } catch (SQLException e) {
            model.addAttribute("mensagem", "Erro ao listar usuários: " + e.getMessage());
        }

        return "usuario";
    }
}
